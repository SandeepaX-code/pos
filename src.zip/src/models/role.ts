import {
  model,
  models,
  Schema,
  type HydratedDocument,
  type InferSchemaType,
} from "mongoose";

import { schemaOptions } from "@/models/_shared";

const RoleSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
      enum: [
        "superAdmin",
        "admin",
        "cashier",
        "waiter",
        "kitchenStaff",
        "inventoryManager",
        "accountant",
      ],
      index: true,
    },
    label: { type: String, required: true, trim: true },
    permissions: [{ type: Schema.Types.ObjectId, ref: "Permission" }],
    description: { type: String, trim: true },
    active: { type: Boolean, default: true },
  },
  schemaOptions,
);

RoleSchema.index({ active: 1, name: 1 });

export type RoleEntity = InferSchemaType<typeof RoleSchema>;
export type RoleDocument = HydratedDocument<RoleEntity>;

export const RoleModel = models.Role || model("Role", RoleSchema);
