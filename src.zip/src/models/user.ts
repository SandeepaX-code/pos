import bcrypt from "bcryptjs";
import { model, models, Schema, type InferSchemaType } from "mongoose";

import type { RoleName } from "@/lib/permissions";
import { schemaOptions } from "@/models/_shared";

const UserSchema = new Schema(
  {
    fullName: { type: String, required: true, trim: true },
    username: {
      type: String,
      required: true,
      unique: true,
      index: true,
      trim: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      index: true,
      trim: true,
      lowercase: true,
    },
    phone: { type: String, required: true, trim: true },
    passwordHash: { type: String, required: true, select: false },
    role: {
      type: String,
      required: true,
      enum: [
        "superAdmin",
        "admin",
        "cashier",
        "waiter",
        "kitchenStaff",
        "inventoryManager",
        "accountant",
      ],
      index: true,
    },
    branchId: {
      type: Schema.Types.ObjectId,
      ref: "Branch",
      required: true,
      index: true,
    },
    active: { type: Boolean, default: true },
    avatar: { type: String },
    lastLoginAt: { type: Date },
    passwordResetToken: { type: String, select: false },
    passwordResetExpiresAt: { type: Date, select: false },
  },
  schemaOptions,
);

UserSchema.index({ branchId: 1, active: 1 });
UserSchema.index({ role: 1, active: 1 });
UserSchema.index({ passwordResetToken: 1 }, { sparse: true });

UserSchema.pre("save", async function hashPassword() {
  if (!this.isModified("passwordHash")) {
    return;
  }

  this.passwordHash = await bcrypt.hash(this.passwordHash, 12);
});

export type UserDocument = InferSchemaType<typeof UserSchema> & {
  role: RoleName;
  comparePassword(password: string): Promise<boolean>;
};

UserSchema.methods.comparePassword = function comparePassword(
  password: string,
) {
  return bcrypt.compare(password, this.passwordHash);
};

export const UserModel = models.User || model("User", UserSchema);
