import { NextRequest, NextResponse } from "next/server";

import { checkoutOrder } from "@/lib/server/restaurant-operations";
import { connectToDatabase } from "@/lib/mongoose";
import { repositories } from "@/lib/data-access";

export async function GET() {
  await connectToDatabase();
  const orders = await repositories.orders.list({});
  return NextResponse.json({ success: true, data: orders });
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const result = await checkoutOrder(body);
  return NextResponse.json({ success: true, data: result }, { status: 201 });
}
