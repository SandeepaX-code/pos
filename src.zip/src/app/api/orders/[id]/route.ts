import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";

import { connectToDatabase } from "@/lib/mongoose";
import { repositories } from "@/lib/data-access";

const orderUpdateSchema = z.object({
  status: z
    .enum(["pending", "preparing", "ready", "delivered", "paid", "void"])
    .optional(),
  discount: z.number().min(0).optional(),
  notes: z.string().max(1000).optional(),
  priority: z.enum(["low", "normal", "high"]).optional(),
});

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  await connectToDatabase();
  const order = await repositories.orders.findById(id);

  if (!order) {
    return NextResponse.json(
      { success: false, message: "Order not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: order });
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const payload = orderUpdateSchema.parse(await request.json());
  await connectToDatabase();
  const order = await repositories.orders.updateById(id, payload);

  if (!order) {
    return NextResponse.json(
      { success: false, message: "Order not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: order });
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  await connectToDatabase();
  const deleted = await repositories.orders.deleteById(id);

  if (!deleted) {
    return NextResponse.json(
      { success: false, message: "Order not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: deleted });
}
