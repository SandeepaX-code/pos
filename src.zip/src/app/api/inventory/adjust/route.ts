import { NextRequest, NextResponse } from "next/server";

import { adjustInventory } from "@/lib/server/restaurant-operations";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const inventory = await adjustInventory(body);
  return NextResponse.json({ success: true, data: inventory });
}
