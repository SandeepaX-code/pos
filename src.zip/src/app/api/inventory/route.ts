import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { repositories } from "@/lib/data-access";
import { inventoryUpsertSchema } from "@/validation/domain";

export async function GET() {
  await connectToDatabase();
  const items = await repositories.inventories.list({});
  return NextResponse.json({ success: true, data: items });
}

export async function POST(request: NextRequest) {
  const body = inventoryUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const item = await repositories.inventories.create(body);
  return NextResponse.json({ success: true, data: item }, { status: 201 });
}
