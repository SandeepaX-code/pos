import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { repositories } from "@/lib/data-access";
import { supplierUpsertSchema } from "@/validation/domain";

export async function GET() {
  await connectToDatabase();
  const suppliers = await repositories.suppliers.list({});
  return NextResponse.json({ success: true, data: suppliers });
}

export async function POST(request: NextRequest) {
  const body = supplierUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const supplier = await repositories.suppliers.create(body);
  return NextResponse.json({ success: true, data: supplier }, { status: 201 });
}
