import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { TableRepository } from "@/lib/table-management/table-repository";
import { TableService } from "@/lib/table-management/table-service";
import {
  tableCreateSchema,
  tableListQuerySchema,
} from "@/validation/table-management";
import { jsonError, jsonSuccess } from "@/utils/http";
import { requireAuth } from "@/middlewares/auth-middleware";

export const dynamic = "force-dynamic";

export const GET = requireAuth(async (req) => {
  try {
    await connectToDatabase();

    const query = tableListQuerySchema.parse(
      Object.fromEntries(new URL(req.url).searchParams.entries()),
    );

    const service = new TableService(new TableRepository());
    const data = await service.listTables({
      filter: {
        search: query.search,
        floor: query.floor,
        section: query.section,
        status: query.status,
        isActive: true,
        branchId: req.user?.branchId,
      },
      pagination: { page: query.page, pageSize: query.pageSize },
      sort: { sortBy: query.sortBy, sortOrder: query.sortOrder },
    });

    return NextResponse.json({ success: true, data });
  } catch (e) {
    return jsonError(400, "Invalid request", "VALIDATION_ERROR");
  }
});

export const POST = requireAuth(async (req) => {
  try {
    await connectToDatabase();

    const body = tableCreateSchema.parse(await req.json());
    const service = new TableService(new TableRepository());
    const data = await service.createTable(body, req.user!);
    return jsonSuccess(data, 201);
  } catch (e) {
    return jsonError(400, "Invalid request", "VALIDATION_ERROR");
  }
});

export const PUT = requireAuth(async () => {
  return jsonError(405, "Method not allowed", "INTERNAL_ERROR");
});

export const DELETE = requireAuth(async () => {
  return jsonError(405, "Method not allowed", "INTERNAL_ERROR");
});
