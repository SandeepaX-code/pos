import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAuth } from "@/middlewares/auth-middleware";
import { jsonError, jsonSuccess } from "@/utils/http";
import { TableRepository } from "@/lib/table-management/table-repository";
import { TableService } from "@/lib/table-management/table-service";
import {
  tableIdParamSchema,
  tableUpdateSchema,
} from "@/validation/table-management";

export const dynamic = "force-dynamic";

export const GET = requireAuth(
  async (_req, { params }: { params: { id: string } }) => {
    try {
      await connectToDatabase();
      const { id } = tableIdParamSchema.parse(params);
      const service = new TableService(new TableRepository());
      const data = await service.getTable(id);
      return jsonSuccess(data);
    } catch {
      return jsonError(404, "Table not found", "NOT_FOUND");
    }
  },
);

export const PUT = requireAuth(
  async (req: NextRequest, { params }: { params: { id: string } }) => {
    try {
      await connectToDatabase();
      const { id } = tableIdParamSchema.parse(params);
      const body = tableUpdateSchema.parse(await req.json());
      const service = new TableService(new TableRepository());
      const data = await service.updateTable(id, body, req.user!);
      return jsonSuccess(data);
    } catch {
      return jsonError(400, "Invalid request", "VALIDATION_ERROR");
    }
  },
);

export const DELETE = requireAuth(
  async (req: NextRequest, { params }: { params: { id: string } }) => {
    try {
      await connectToDatabase();
      const { id } = tableIdParamSchema.parse(params);
      const service = new TableService(new TableRepository());
      const data = await service.deleteTable(id, req.user!);
      return jsonSuccess(data);
    } catch {
      return jsonError(404, "Table not found", "NOT_FOUND");
    }
  },
);
