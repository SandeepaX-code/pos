import { connectToDatabase } from "@/lib/mongoose";
import { requireAuth } from "@/middlewares/auth-middleware";
import { jsonError, jsonSuccess } from "@/utils/http";
import { TableRepository } from "@/lib/table-management/table-repository";
import { TableService } from "@/lib/table-management/table-service";
import { tableIdParamSchema } from "@/validation/table-management";
import type { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

type Params = { id: string };

export const PATCH = requireAuth(
  async (req: NextRequest, { params }: { params: Params }) => {
    try {
      await connectToDatabase();
      const { id } = tableIdParamSchema.parse(params);
      const service = new TableService(new TableRepository());
      const data = await service.changeStatus({
        id,
        action: "reserve",
        user: req.user!,
      });
      return jsonSuccess(data);
    } catch {
      return jsonError(400, "Invalid request", "INVALID_TRANSITION");
    }
  },
);
