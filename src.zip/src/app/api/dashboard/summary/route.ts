import { NextResponse } from "next/server";

import { listDashboardSummary } from "@/lib/server/restaurant-operations";

export async function GET() {
  const summary = await listDashboardSummary();
  return NextResponse.json({ success: true, data: summary });
}
