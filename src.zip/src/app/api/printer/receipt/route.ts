import { NextRequest } from "next/server";

import {
  createCustomerReceipt,
  createKitchenReceipt,
} from "@/lib/printer/receipts";
import type { Order, KitchenOrder } from "@/types/domain";

export async function POST(request: NextRequest) {
  const body = (await request.json()) as {
    type: "customer" | "kitchen";
    paymentMethod?: string;
    order: Order | KitchenOrder;
  };

  const payload =
    body.type === "customer"
      ? createCustomerReceipt(body.order as Order, body.paymentMethod ?? "cash")
      : createKitchenReceipt(body.order);

  return new Response(payload, {
    headers: {
      "Content-Type": "application/octet-stream",
      "Content-Disposition": `attachment; filename=${body.type}-receipt.bin`,
    },
  });
}
