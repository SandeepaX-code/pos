import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { repositories } from "@/lib/data-access";
import { customerUpsertSchema } from "@/validation/domain";

export async function GET() {
  await connectToDatabase();
  const customers = await repositories.customers.list({});
  return NextResponse.json({ success: true, data: customers });
}

export async function POST(request: NextRequest) {
  const body = customerUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const customer = await repositories.customers.create(body);
  return NextResponse.json({ success: true, data: customer }, { status: 201 });
}
