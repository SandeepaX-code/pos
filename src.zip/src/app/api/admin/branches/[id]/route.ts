import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAdminToken } from "@/lib/server/admin-auth";
import { repositories } from "@/lib/data-access";
import { branchUpsertSchema } from "@/validation/admin";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const { id } = await params;
  const parsed = branchUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const branch = await repositories.branches.updateById(id, parsed);

  if (!branch) {
    return NextResponse.json(
      { success: false, message: "Branch not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: branch });
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const { id } = await params;
  await connectToDatabase();
  const deleted = await repositories.branches.deleteById(id);

  if (!deleted) {
    return NextResponse.json(
      { success: false, message: "Branch not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: deleted });
}
