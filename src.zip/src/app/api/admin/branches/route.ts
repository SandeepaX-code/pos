import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAdminToken } from "@/lib/server/admin-auth";
import { repositories } from "@/lib/data-access";
import { branchUpsertSchema } from "@/validation/admin";

export async function GET(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  await connectToDatabase();
  const branches = await repositories.branches.list({});
  return NextResponse.json({ success: true, data: branches });
}

export async function POST(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const parsed = branchUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const branch = await repositories.branches.create(parsed);
  return NextResponse.json({ success: true, data: branch }, { status: 201 });
}
