import bcrypt from "bcryptjs";
import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAdminToken } from "@/lib/server/admin-auth";
import { UserModel } from "@/models/user";
import { adminUserUpdateSchema } from "@/validation/admin";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const { id } = await params;
  const parsed = adminUserUpdateSchema.parse(await request.json());
  const payload = { ...parsed } as Record<string, unknown>;

  if (parsed.password) {
    payload.passwordHash = await bcrypt.hash(parsed.password, 12);
    delete payload.password;
  }

  await connectToDatabase();
  const user = await UserModel.findByIdAndUpdate(id, payload, {
    new: true,
    runValidators: true,
  })
    .lean()
    .exec();

  if (!user) {
    return NextResponse.json(
      { success: false, message: "User not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: user });
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const { id } = await params;
  await connectToDatabase();
  const deleted = await UserModel.findByIdAndDelete(id).lean().exec();

  if (!deleted) {
    return NextResponse.json(
      { success: false, message: "User not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: deleted });
}
