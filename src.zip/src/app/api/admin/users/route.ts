import bcrypt from "bcryptjs";
import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAdminToken } from "@/lib/server/admin-auth";
import { UserModel } from "@/models/user";
import { adminUserSchema } from "@/validation/admin";

export async function GET(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  await connectToDatabase();
  const users = await UserModel.find().sort({ createdAt: -1 }).lean().exec();
  return NextResponse.json({ success: true, data: users });
}

export async function POST(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const parsed = adminUserSchema.parse(await request.json());
  await connectToDatabase();

  const user = await UserModel.create({
    ...parsed,
    passwordHash: await bcrypt.hash(parsed.password, 12),
  });

  return NextResponse.json({ success: true, data: user }, { status: 201 });
}
