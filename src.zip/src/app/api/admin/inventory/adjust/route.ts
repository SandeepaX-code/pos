import { NextRequest, NextResponse } from "next/server";

import { adjustInventory } from "@/lib/server/restaurant-operations";
import { requireAdminToken } from "@/lib/server/admin-auth";

export async function POST(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const body = await request.json();
  const inventory = await adjustInventory(body);
  return NextResponse.json({ success: true, data: inventory });
}
