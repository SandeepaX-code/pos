import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAdminToken } from "@/lib/server/admin-auth";
import { repositories } from "@/lib/data-access";
import { inventoryItemUpsertSchema } from "@/validation/admin";

export async function GET(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  await connectToDatabase();
  const items = await repositories.inventories.list({});
  return NextResponse.json({ success: true, data: items });
}

export async function POST(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const parsed = inventoryItemUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const item = await repositories.inventories.create(parsed);
  return NextResponse.json({ success: true, data: item }, { status: 201 });
}
