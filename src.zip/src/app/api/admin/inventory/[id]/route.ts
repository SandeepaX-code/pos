import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAdminToken } from "@/lib/server/admin-auth";
import { repositories } from "@/lib/data-access";
import { inventoryItemUpsertSchema } from "@/validation/admin";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const { id } = await params;
  const parsed = inventoryItemUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const item = await repositories.inventories.updateById(id, parsed);

  if (!item) {
    return NextResponse.json(
      { success: false, message: "Inventory item not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: item });
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const { id } = await params;
  await connectToDatabase();
  const deleted = await repositories.inventories.deleteById(id);

  if (!deleted) {
    return NextResponse.json(
      { success: false, message: "Inventory item not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: deleted });
}
