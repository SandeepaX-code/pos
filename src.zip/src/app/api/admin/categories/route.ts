import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAdminToken } from "@/lib/server/admin-auth";
import { repositories } from "@/lib/data-access";
import { categoryUpsertSchema } from "@/validation/admin";

export async function GET(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  await connectToDatabase();
  const categories = await repositories.categories.list({});
  return NextResponse.json({ success: true, data: categories });
}

export async function POST(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const parsed = categoryUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const category = await repositories.categories.create(parsed);
  return NextResponse.json({ success: true, data: category }, { status: 201 });
}
