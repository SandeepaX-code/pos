import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAdminToken } from "@/lib/server/admin-auth";
import { repositories } from "@/lib/data-access";
import { categoryUpsertSchema } from "@/validation/admin";

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const { id } = await params;
  const parsed = categoryUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const category = await repositories.categories.updateById(id, parsed);

  if (!category) {
    return NextResponse.json(
      { success: false, message: "Category not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: category });
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const { id } = await params;
  await connectToDatabase();
  const deleted = await repositories.categories.deleteById(id);

  if (!deleted) {
    return NextResponse.json(
      { success: false, message: "Category not found" },
      { status: 404 },
    );
  }

  return NextResponse.json({ success: true, data: deleted });
}
