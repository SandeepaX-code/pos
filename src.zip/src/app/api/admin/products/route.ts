import { NextRequest, NextResponse } from "next/server";

import { connectToDatabase } from "@/lib/mongoose";
import { requireAdminToken } from "@/lib/server/admin-auth";
import { repositories } from "@/lib/data-access";
import { productUpsertSchema } from "@/validation/admin";

export async function GET(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  await connectToDatabase();
  const products = await repositories.products.list({});
  return NextResponse.json({ success: true, data: products });
}

export async function POST(request: NextRequest) {
  if (!(await requireAdminToken(request))) {
    return NextResponse.json(
      { success: false, message: "Forbidden" },
      { status: 403 },
    );
  }

  const parsed = productUpsertSchema.parse(await request.json());
  await connectToDatabase();
  const product = await repositories.products.create(parsed);
  return NextResponse.json({ success: true, data: product }, { status: 201 });
}
