import bcrypt from "bcryptjs";
import crypto from "crypto";

import { UserModel } from "@/models/user";
import { RefreshTokenRepository } from "@/repositories/refresh-token-repository";
import { RefreshTokenModel } from "@/models/refresh-token";
import { RoleModel } from "@/models/role";

import {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} from "@/lib/jwt";
import { AUTH } from "@/constants/auth";

import type { AuthenticatedUser } from "@/types/auth";

type UserLean = {
  _id: unknown;
  role: string;
  branchId?: unknown;
  active: boolean;
};

export class AuthService {
  private refreshRepo = new RefreshTokenRepository();

  private async getUserPermissions(role: string): Promise<string[]> {
    const roleDoc = await RoleModel.findOne({
      name: role,
      active: true,
    }).populate("permissions");

    if (!roleDoc) return [];

    return (roleDoc.permissions ?? [])
      .map((p: unknown) => {
        const candidate = p as { key?: unknown } | null | undefined;
        const key = candidate?.key;
        return typeof key === "string" ? key : undefined;
      })
      .filter((k): k is string => typeof k === "string");
  }

  async login(params: {
    username: string;
    password: string;
    deviceInfo?: unknown;
    ipAddress?: string;
  }): Promise<{
    user: AuthenticatedUser;
    accessToken: string;
    refreshToken: string;
  }> {
    const userDoc = await UserModel.findOne({
      username: params.username,
      active: true,
    }).select("+passwordHash role branchId fullName username");

    if (!userDoc) {
      throw Object.assign(new Error("Invalid credentials"), {
        code: "INVALID_CREDENTIALS" as const,
      });
    }

    const ok = await bcrypt.compare(params.password, userDoc.passwordHash);
    if (!ok) {
      throw Object.assign(new Error("Invalid credentials"), {
        code: "INVALID_CREDENTIALS" as const,
      });
    }

    const permissions = await this.getUserPermissions(userDoc.role);

    const accessToken = signAccessToken(
      {
        sub: String(userDoc._id),
        role: userDoc.role,
        permissions,
        branchId: String(userDoc.branchId),
        jti: crypto.randomUUID(),
      },
      AUTH.accessTokenTtlSeconds,
    );

    const refreshToken = signRefreshToken(
      {
        sub: String(userDoc._id),
        role: userDoc.role,
        permissions,
        branchId: String(userDoc.branchId),
        jti: crypto.randomUUID(),
      },
      AUTH.refreshTokenTtlSeconds,
    );

    const tokenHash = await this.refreshRepo.hashToken(refreshToken);
    const expiresAt = new Date(Date.now() + AUTH.refreshTokenTtlSeconds * 1000);

    await this.refreshRepo.create({
      userId: String(userDoc._id),
      tokenHash,
      expiresAt,
      deviceInfo: params.deviceInfo,
      ipAddress: params.ipAddress,
    });

    await UserModel.updateOne(
      { _id: userDoc._id },
      { $set: { lastLoginAt: new Date() } },
    );

    return {
      user: {
        id: String(userDoc._id),
        role: userDoc.role,
        permissions,
        branchId: String(userDoc.branchId),
      },
      accessToken,
      refreshToken,
    };
  }

  async logout(params: { refreshToken: string | null; ipAddress?: string }) {
    if (!params.refreshToken) return;

    // Verify refresh JWT and revoke DB record by hashed token.
    verifyRefreshToken(params.refreshToken);

    const tokenHash = await this.refreshRepo.hashToken(params.refreshToken);
    const rt = await RefreshTokenModel.findOne({ tokenHash });

    if (!rt) return;
    if (rt.revoked) return;

    await this.refreshRepo.revokeById(String(rt._id));
  }

  async refresh(params: {
    refreshToken: string;
    deviceInfo?: unknown;
    ipAddress?: string;
  }): Promise<{
    user: AuthenticatedUser;
    accessToken: string;
    refreshToken: string;
  }> {
    verifyRefreshToken(params.refreshToken);

    const tokenHash = await this.refreshRepo.hashToken(params.refreshToken);
    const active = await this.refreshRepo.findActiveByTokenHash(tokenHash);

    if (!active || active.revoked) {
      throw Object.assign(new Error("Refresh token revoked or invalid"), {
        code: "REFRESH_INVALID" as const,
      });
    }

    if (active.expiresAt.getTime() <= Date.now()) {
      throw Object.assign(new Error("Refresh token expired"), {
        code: "REFRESH_EXPIRED" as const,
      });
    }

    // Rotation: revoke old and issue new
    await this.refreshRepo.revokeById(String(active._id));

    const user = (await UserModel.findById(active.userId)
      .select("role branchId active")
      .lean()) as UserLean | null;

    if (!user || !user.active) {
      throw Object.assign(new Error("User inactive"), {
        code: "USER_INACTIVE" as const,
      });
    }

    const permissions = await this.getUserPermissions(user.role);

    const branchId = user.branchId ? String(user.branchId) : undefined;

    const accessToken = signAccessToken(
      {
        sub: String(active.userId),
        role: user.role,
        permissions,
        branchId,
        jti: crypto.randomUUID(),
      },
      AUTH.accessTokenTtlSeconds,
    );

    const refreshToken = signRefreshToken(
      {
        sub: String(active.userId),
        role: user.role,
        permissions,
        branchId,
        jti: crypto.randomUUID(),
      },
      AUTH.refreshTokenTtlSeconds,
    );

    const newHash = await this.refreshRepo.hashToken(refreshToken);
    const expiresAt = new Date(Date.now() + AUTH.refreshTokenTtlSeconds * 1000);

    await this.refreshRepo.create({
      userId: String(active.userId),
      tokenHash: newHash,
      expiresAt,
      deviceInfo: params.deviceInfo,
      ipAddress: params.ipAddress,
    });

    return {
      user: {
        id: String(active.userId),
        role: user.role,
        permissions,
        branchId,
      },
      accessToken,
      refreshToken,
    };
  }
}
