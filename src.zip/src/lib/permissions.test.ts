import { describe, expect, it } from "vitest";

import { getRoleLabel, hasPermission } from "./permissions";

describe("permissions", () => {
  it("grants super admin permissions", () => {
    expect(hasPermission("superAdmin", "backup.restore")).toBe(true);
  });

  it("returns a readable role label", () => {
    expect(getRoleLabel("inventoryManager")).toBe("Inventory Manager");
  });
});
