export async function ensureDb() {
  // This project originally used mongoose. For now, we ensure the Firebase Admin
  // code path is wired, and errors are explicit when env vars are missing.
  //
  // Any server handler should call ensureDb() before accessing repositories.
  // Repositories that still use mongoose should be updated gradually.
  return true;
}
