import { getFirebaseAdminDb } from "@/lib/firebase/admin";
import type { FirestoreCrudRepository } from "@/lib/repositories/firestore-crud-repository";
import { createFirestoreCrudRepository } from "@/lib/repositories/firestore-crud-repository";
import { createCrudService } from "@/lib/services/crud-service";

// Firebase-backed repositories/services.
// NOTE: current FirestoreCrudRepository only supports empty-filter list/count.
// For complex Mongo-style queries, we will extend repositories per entity.

const db = getFirebaseAdminDb();

function r<T extends { id?: string }>(
  collectionPath: string,
): FirestoreCrudRepository<
  T,
  Record<string, unknown>,
  Record<string, unknown>
> {
  return createFirestoreCrudRepository<
    T,
    Record<string, unknown>,
    Record<string, unknown>
  >(db, {
    collectionPath,
  });
}

type AnyDoc = { id?: string };

export const repositories = {
  activities: r<AnyDoc>("activityLogs"),
  bills: r<AnyDoc>("bills"),
  branches: r<AnyDoc>("branches"),
  categories: r<AnyDoc>("categories"),
  customers: r<AnyDoc>("customers"),
  inventories: r<AnyDoc>("inventories"),
  kitchenOrders: r<AnyDoc>("kitchenOrders"),
  notifications: r<AnyDoc>("notifications"),
  orderItems: r<AnyDoc>("orderItems"),
  orders: r<AnyDoc>("orders"),
  payments: r<AnyDoc>("payments"),
  permissions: r<AnyDoc>("permissions"),
  products: r<AnyDoc>("products"),
  purchaseOrders: r<AnyDoc>("purchaseOrders"),
  recipes: r<AnyDoc>("recipes"),
  reservations: r<AnyDoc>("reservations"),
  restaurantTables: r<AnyDoc>("restaurantTables"),
  roles: r<AnyDoc>("roles"),
  settings: r<AnyDoc>("settings"),
  stockMovements: r<AnyDoc>("stockMovements"),
  suppliers: r<AnyDoc>("suppliers"),
  users: r<AnyDoc>("users"),
} as const;

export const services = {
  activities: createCrudService(repositories.activities),
  bills: createCrudService(repositories.bills),
  branches: createCrudService(repositories.branches),
  categories: createCrudService(repositories.categories),
  customers: createCrudService(repositories.customers),
  inventories: createCrudService(repositories.inventories),
  kitchenOrders: createCrudService(repositories.kitchenOrders),
  notifications: createCrudService(repositories.notifications),
  orderItems: createCrudService(repositories.orderItems),
  orders: createCrudService(repositories.orders),
  payments: createCrudService(repositories.payments),
  permissions: createCrudService(repositories.permissions),
  products: createCrudService(repositories.products),
  purchaseOrders: createCrudService(repositories.purchaseOrders),
  recipes: createCrudService(repositories.recipes),
  reservations: createCrudService(repositories.reservations),
  restaurantTables: createCrudService(repositories.restaurantTables),
  roles: createCrudService(repositories.roles),
  settings: createCrudService(repositories.settings),
  stockMovements: createCrudService(repositories.stockMovements),
  suppliers: createCrudService(repositories.suppliers),
  users: createCrudService(repositories.users),
} as const;
