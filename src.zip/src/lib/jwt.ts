import jwt from "jsonwebtoken";

export type JwtClaims = {
  sub: string;
  role: string;
  permissions: string[];
  branchId?: string;
  jti?: string;
};

const getSecret = () => {
  const secret = process.env.JWT_ACCESS_SECRET;
  if (!secret) throw new Error("JWT_ACCESS_SECRET is required");
  return secret;
};

export function signAccessToken(claims: JwtClaims, expiresInSeconds: number) {
  return jwt.sign(claims, getSecret(), {
    expiresIn: expiresInSeconds,
    issuer: "restaurant-pos",
    audience: "restaurant-pos-api",
  });
}

const getRefreshSecret = () => {
  const secret = process.env.JWT_REFRESH_SECRET;
  if (!secret) throw new Error("JWT_REFRESH_SECRET is required");
  return secret;
};

export function signRefreshToken(claims: JwtClaims, expiresInSeconds: number) {
  return jwt.sign(claims, getRefreshSecret(), {
    expiresIn: expiresInSeconds,
    issuer: "restaurant-pos",
    audience: "restaurant-pos-api",
  });
}

export function verifyAccessToken(token: string): JwtClaims {
  const decoded = jwt.verify(token, getSecret(), {
    issuer: "restaurant-pos",
    audience: "restaurant-pos-api",
  });
  return decoded as JwtClaims;
}

export function verifyRefreshToken(token: string): JwtClaims {
  const decoded = jwt.verify(token, getRefreshSecret(), {
    issuer: "restaurant-pos",
    audience: "restaurant-pos-api",
  });
  return decoded as JwtClaims;
}
