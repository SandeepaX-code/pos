import { extendZodWithOpenApi } from "./zod-to-openapi";
import type { ZodTypeAny } from "zod";
import { z } from "zod";

extendZodWithOpenApi(z);

export function zodToOpenApiSchema(schema: ZodTypeAny) {
  return schema;
}
