import type { RouteConfig } from "./types";
import { registry } from "./registry";

export function createRoute<T>(route: RouteConfig<T>) {
  registry.registerPath(route);
  return route;
}
