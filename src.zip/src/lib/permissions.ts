export const rolePermissions = {
  superAdmin: [
    "users.create",
    "users.update",
    "users.delete",
    "users.disable",
    "roles.assign",
    "branches.manage",
    "settings.manage",
    "taxes.manage",
    "printers.manage",
    "tables.manage",
    "categories.manage",
    "menu.manage",
    "inventory.manage",
    "discounts.manage",
    "promotions.manage",
    "customers.manage",
    "suppliers.manage",
    "reports.view",
    "backup.create",
    "backup.restore",
  ],
  admin: [
    "users.create",
    "users.update",
    "roles.assign",
    "branches.manage",
    "settings.manage",
    "taxes.manage",
    "printers.manage",
    "tables.manage",
    "categories.manage",
    "menu.manage",
    "inventory.manage",
    "discounts.manage",
    "promotions.manage",
    "customers.manage",
    "suppliers.manage",
    "reports.view",
  ],
  cashier: ["orders.checkout", "payments.create", "reports.view"],
  waiter: [
    "orders.create",
    "orders.update",
    "tables.manage",
    "customers.manage",
  ],
  kitchenStaff: ["kitchen.view", "kitchen.update", "kitchen.print"],
  inventoryManager: [
    "inventory.manage",
    "inventory.receive",
    "purchaseOrders.manage",
    "suppliers.manage",
  ],
  accountant: [
    "reports.view",
    "taxes.manage",
    "payments.view",
    "expenses.manage",
  ],
} as const;

export type RoleName = keyof typeof rolePermissions;

export function hasPermission(role: RoleName, permission: string) {
  return rolePermissions[role].includes(permission as never);
}

export function getRoleLabel(role: RoleName) {
  return role
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/^./, (char) => char.toUpperCase());
}
