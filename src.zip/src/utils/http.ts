import { NextResponse } from "next/server";

type ErrorCode =
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "VALIDATION_ERROR"
  | "CONFLICT"
  | "NOT_FOUND"
  | "INTERNAL_ERROR";

export function jsonSuccess<T>(data: T, status = 200) {
  return NextResponse.json({ success: true, data }, { status });
}

export function jsonError(
  status: number,
  message: string,
  errorCode: ErrorCode,
  extra?: Record<string, unknown>,
) {
  return NextResponse.json(
    {
      success: false,
      message,
      errorCode,
      ...(extra ? { details: extra } : {}),
    },
    { status },
  );
}
